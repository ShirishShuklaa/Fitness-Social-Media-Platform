package main.java.com.linhtch90.psnbackend.entity;

public @interface Entity {

}
