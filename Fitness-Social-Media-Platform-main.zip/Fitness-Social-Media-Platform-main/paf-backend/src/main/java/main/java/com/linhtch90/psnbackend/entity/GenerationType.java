package main.java.com.linhtch90.psnbackend.entity;

public class GenerationType {

    public static final String IDENTITY = null;

}
