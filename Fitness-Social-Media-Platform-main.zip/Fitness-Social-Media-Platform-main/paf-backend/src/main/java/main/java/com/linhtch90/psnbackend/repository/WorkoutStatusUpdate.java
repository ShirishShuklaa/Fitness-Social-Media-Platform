package main.java.com.linhtch90.psnbackend.repository;

public interface WorkoutStatusUpdate {

}
